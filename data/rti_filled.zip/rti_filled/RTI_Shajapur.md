To,
The Public Information Officer (लोक सूचना अधिकारी),
Office of the Collector / Superintendent Land Records (अधीक्षक भू-अभिलेख),
District: Shajapur, Madhya Pradesh.

Subject: Information under the Right to Information Act, 2005 — village-wise mutation
(नामांतरण) records for abadi / rural-habitation (SVAMITVA आबादी) land.

Respected Sir/Madam,

Under Section 6 of the Right to Information Act, 2005, I request the following information for the
4 villages of District Shajapur listed in Annexure A below (abadi land surveyed/recorded under
the SVAMITVA scheme). Please provide it village-wise, as on [DATE]:

1. The number of mutation (नामांतरण) entries recorded in the mutation register (नामांतरण पंजी) for
   the abadi / rural-habitation land of each listed village, since the issue of SVAMITVA property
   cards (अधिकार अभिलेख, प्ररूप तीन) for that village.

2. Of the entries in (1), the number recorded pursuant to a mortgage / charge / bank loan
   (बंधक / दृष्टिबंधक / भू-ऋण) on the property.

3. Whether the abadi rights record (अधिकार अभिलेख, प्ररूप तीन) of each listed village carries any
   entry in column 11 — भूमि पर विल्लंगम तथा प्रभार (encumbrance); if yes, the number of parcels so
   recorded, village-wise.

4. The total number of SVAMITVA property cards / अधिकार अभिलेख issued for each listed village.

5. A certified copy or extract of the नामांतरण पंजी entry, if any, for the specific Survey/Gat
   number listed against each village in Annexure A. (If this attracts a copying fee, please
   intimate the amount before proceeding.)

If any part of this information is held by another public authority, kindly transfer that part
under Section 6(3) and inform me. If it cannot be provided in the requested format, please provide
it in whatever form it is held.

I enclose the application fee of ₹10 by way of [IPO No. / court-fee stamp / DD / online receipt].
I am [not] below the poverty line.

Applicant: [FULL NAME]
Address: [POSTAL ADDRESS]
Email / Phone: [EMAIL] / [PHONE]
Date: [DATE]        Place: [PLACE]
Signature: ____________________

---

Annexure A — District Shajapur (4 villages)

| # | Tehsil | Village | Survey no. |
|---|---|---|---|
| 1 | Kalapipal | Akodi | 50-227 |
| 2 | Kalapipal | Tilawad | 50-977 |
| 3 | Shajapur | Moolikheda | 50-473 |
| 4 | Shajapur | Patoli | 50-820 |
